<?php
/**
Template Name: Team members list
 */
global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'team';

get_template_part('blog');
?>