<?php
/*
Template Name: Only Audio
*/

global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'audio';

get_template_part('blog');
?>