<?php
/*
Template Name: Only Video
*/

global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'video';

get_template_part('blog');
?>