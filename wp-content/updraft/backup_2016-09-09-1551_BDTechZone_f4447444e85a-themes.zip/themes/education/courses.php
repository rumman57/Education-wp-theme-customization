<?php
/**
Template Name: Courses streampage
 */
global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'courses';

get_template_part('blog');
?>