<?php
/*
Template Name: Only Gallery
*/

global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'gallery';

get_template_part('blog');
?>